Decay Fracture RP - Minecraft Java 1.21.11

Item test:
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1001]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1002]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1003]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1004]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1005]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1006]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1007]}] 1
/give @p minecraft:echo_shard[minecraft:custom_model_data={floats:[1008]}] 1

Direct item model fallback test:
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:decay_fracture"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:singu_energy"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:air_bottle"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:thorns_bottle"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:trapper_bottle"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:vodoo_bottle"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:villager_bottle"] 1
/give @p minecraft:echo_shard[minecraft:item_model="blissgems:war_bottle"] 1

Font char tests:
/tellraw @p {"text":"\uE001"}
/tellraw @p {"text":"\uE007"}
/tellraw @p {"text":"\uE002"}
/tellraw @p {"text":"\uE008"}
/tellraw @p {"text":"\uE009"}
/tellraw @p {"text":"\uE003"}
/tellraw @p {"text":"\uE00A"}
/tellraw @p {"text":"\uE004"}
/tellraw @p {"text":"\uE00B"}
/tellraw @p {"text":"\uE005"}
/tellraw @p {"text":"\uE00C"}
/tellraw @p {"text":"\uE006"}
/tellraw @p {"text":"\uE00E"}
/tellraw @p {"text":"\uE00D"}
/tellraw @p {"text":"\uE011"}
/tellraw @p {"text":"\uE00F"}
/tellraw @p {"text":"\uE012"}
/tellraw @p {"text":"\uE010"}
/tellraw @p {"text":"\uE013"}
/tellraw @p {"text":"\uE014"}
/tellraw @p {"text":"\uE015"}
/tellraw @p {"text":"\uE016"}
/tellraw @p {"text":"\uE017"}
/tellraw @p {"text":"\uE018"}

Do not type /uE001 in chat. Use \uE001 inside JSON text, or paste the actual character.
